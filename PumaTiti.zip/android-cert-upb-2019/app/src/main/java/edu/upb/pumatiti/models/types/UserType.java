package edu.upb.pumatiti.models.types;

public enum UserType {
    REGULAR_USER,
    HOST,
    ANALYST
}
