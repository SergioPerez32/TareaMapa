package edu.upb.pumatiti.models.ui;

import edu.upb.pumatiti.models.types.BusType;

public class BusMarker {
    private String plate;

    private BusType type;
}
