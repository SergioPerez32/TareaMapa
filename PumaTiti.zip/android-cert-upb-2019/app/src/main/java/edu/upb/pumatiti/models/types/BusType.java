package edu.upb.pumatiti.models.types;

public enum BusType {
    PUMA,
    CHIKITITI
}
