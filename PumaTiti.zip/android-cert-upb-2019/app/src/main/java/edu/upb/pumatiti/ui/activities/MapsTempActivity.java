package edu.upb.pumatiti.ui.activities;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;

import edu.upb.pumatiti.R;

public class MapsTempActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_temp);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-16.508825, -68.131221);
        LatLng sydney1 = new LatLng(-16.509698, -68.126858);
        LatLng sydney2 = new LatLng(-16.510200, -68.126210);
        LatLng sydney3 = new LatLng(-16.502704, -68.120464);
        LatLng sydney4 = new LatLng(-16.484246, -68.122669);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Sgt. Peppers"));
        mMap.addMarker(new MarkerOptions().position(sydney1).title("Beef and Beer"));
        mMap.addMarker(new MarkerOptions().position(sydney2).title("Alexander Coffee"));
        mMap.addMarker(new MarkerOptions().position(sydney3).title("Texas"));
        mMap.addMarker(new MarkerOptions().position(sydney4).title("El Super Silpancho"));

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney,16));

    }
}
